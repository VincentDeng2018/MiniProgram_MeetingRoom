// miniprogram/pages/MeetingRoom/MeetingRoom.js
wx.cloud.init()
const app = getApp()
const db = wx.cloud.database()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        RoomListRadio: [
            { Name: '1号会议室', Location: 'N/A', Capacity: '0', Tools: 'N/A', Index: 0, checked: false},
            { Name: '2号会议室', Location: 'N/A', Capacity: '0', Tools: 'N/A', Index: 1, checked: false},
            { Name: '3号会议室', Location: 'N/A', Capacity: '0', Tools: 'N/A', Index: 2, checked: false},
        ],

        RoomSelectNum: app.globalData.RoomSelectNum
    },
    
    RefreshMeetingRoomScreen: function () 
    {
        var RoomListTemp = app.getRoomInfo(255);

        //Refresh meeting room list
        if (RoomListTemp != null)
        {
            var i;
            for(i = 0; i < RoomListTemp.length; i++)
            {
                this.data.RoomListRadio[i].Name = RoomListTemp[i].Name;
                this.data.RoomListRadio[i].Capacity = RoomListTemp[i].Capacity;
                this.data.RoomListRadio[i].Location = RoomListTemp[i].Location;
                this.data.RoomListRadio[i].Tools = RoomListTemp[i].Tools;
                this.data.RoomListRadio[i].checked = (app.globalData.RoomSelectNum == i);
            }
            this.setData({
                RoomListRadio: this.data.RoomListRadio
            }

            )
        }

        // Refresh meeting room detail by update select room number
        this.setData({
            RoomSelectNum: app.globalData.RoomSelectNum
        })
    },

    MeetingRoomRadioChange: function(e)
    {
        console.log(e);

        var RoomListRadioTemp = this.data.RoomListRadio;
        var RoomSelectNumTemp = 0;

        if(e.detail.value == '1号会议室')
        {
            RoomListRadioTemp[0].checked = true;
            RoomListRadioTemp[1].checked = false;
            RoomListRadioTemp[2].checked = false;

            RoomSelectNumTemp = 0;
        }
        else if(e.detail.value == '2号会议室')
        {
            RoomListRadioTemp[0].checked = false;
            RoomListRadioTemp[1].checked = true;
            RoomListRadioTemp[2].checked = false;

            RoomSelectNumTemp = 1;
        }
        else if (e.detail.value == '3号会议室') 
        {
            RoomListRadioTemp[0].checked = false;
            RoomListRadioTemp[1].checked = false;
            RoomListRadioTemp[2].checked = true;

            RoomSelectNumTemp = 2;
        }

        this.setData({
            RoomListRadio: RoomListRadioTemp,
            RoomSelectNum: RoomSelectNumTemp
        });

        app.setSelectRoomNumber(RoomSelectNumTemp);

        this.RefreshMeetingRoomScreen();
    },

    ReserveButtonClick: function()
    {
        wx.switchTab({
            url: '../ReserveMeeting/ReserveMeeting',
        })

        console.log('button click');
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.RefreshMeetingRoomScreen();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})