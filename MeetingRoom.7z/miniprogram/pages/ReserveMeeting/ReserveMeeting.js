// miniprogram/pages/ReserveMeeting/ReserveMeeting.js
const app = getApp();
const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        RoomName: app.globalData.MeetingRoomList[app.globalData.RoomSelectNum],
        bNoMeeting: true,
        RoomNameList: ["1号会议室", "2号会议室", "3号会议室"],
        DateValid: false,
        TimeValid: false,
        RoomSelectNum: app.globalData.RoomSelectNum,
        MeetingDate: "",
        MeetingStartTime: "",
        MeetingEndTime: "",
        MeetingContent: "",
        MeetingComment: "",
        MeetingAgenda: [],
        //   { Content: "Test 5", StartTime: "08:30", EndTime: "09:30", Comment: "VincentDeng-15914137911", Index: 8},
        //   { Content: "Test 2", StartTime: "09:30", EndTime: "10:30", Comment: "VincentDeng-15914137911",Index: 2},
        //   { Content: "Test 3", StartTime: "07:30", EndTime: "08:30", Comment: "VincentDeng-15914137911", Index: 3 },
        //
        UserOpenId:""
    },

    RefreshRoomTitleName: function()
    {
        var SelectRoom = app.getSelectRoomNumber();
        var RoomInfo = app.getRoomInfo(SelectRoom);

        this.setData({
            RoomName: RoomInfo.Name
        });
    },

    RefreshRoomSelectBox: function()
    {
        var RoomListTemp = app.getRoomInfo(255);
        
        this.setData({
            RoomSelectNum: app.getSelectRoomNumber()
        });

        if (RoomListTemp.length > 0) {
            var i;

            for (i = 0; i < RoomListTemp.length; i++) {
                this.data.RoomNameList[i] = RoomListTemp[i].Name
            }
            this.setData({
                RoomList: this.data.RoomNameList
            })
        }

        if(this.data.MeetingDate != '')
        {
            this.UpdateReservedMeetingAgenda(this.data.MeetingDate)
        }
    },

    RefreshReservedMeetingScreen: function()
    {
        this.setData({
            MeetingStartTime: "",
            MeetingEndTime: "",
            MeetingContent: "",
            MeetingComment: "",
        })

        // 更新预定信息标题栏
        this.RefreshRoomTitleName();
        
        // 更新会议室下拉选择框文本，以防管理员动态修改云存储内容
        this.RefreshRoomSelectBox();

        // 更新当前选定会议室在选定日期下的使用情况 
    },
    
    BindRoomChange: function(e)
    {
        console.log("select Room#" + e.detail.value);
        app.setSelectRoomNumber(e.detail.value -'0');
        this.RefreshRoomTitleName();
        this.RefreshRoomSelectBox();
    },

    ReserveButtonClick: function()
    {
        this.ReserveInfoValidCheck();
    },
    
    InsertOneReserveMeetingRecord: function()
    {
        db.collection('ReservedRecord').add({
            // data 字段表示需新增的 JSON 数据
            data: {
              Date: this.data.MeetingDate,
              StartTime: this.data.MeetingStartTime,
              EndTime: this.data.MeetingEndTime,
              Content: this.data.MeetingContent,
              Comment: this.data.MeetingComment,
              RoomSelectNum: app.globalData.RoomSelectNum,
            }
          })
          .then(res => {
            console.log(res)
          })
          .catch(console.error)
    },

    ReserveInfoValidCheck: function()
    {
        var subScreenContent = "您已经成功预订会议室"
        var title = "预定成功"
        var reservedInfoValid = false

        // Meeting content valid check
        if (this.data.MeetingContent == '')
        {
            subScreenContent = "请填写会议内容";
        }
        else if(this.data.MeetingDate == '')
        {
            subScreenContent = "请选择会议日期";
        }
        else if(this.data.MeetingStartTime == '')
        {
            subScreenContent = "请选择会议开始时间";
        }
        else if(this.data.MeetingEndTime == '')
        {
            subScreenContent = "请选择会议结束时间";
        }
        else if (this.CommentValidCheck(this.data.MeetingComment) == 0)
        {
            subScreenContent = "请填写完整的发起人信息，包含发起人与电话，方便协调！";
        }
        else
        {
            // check whether time confict or not 
            if (this.data.MeetingAgenda.length > 0) 
            {
                for (var i = 0; i < this.data.MeetingAgenda.length; i++) 
                {
                    if (   this.data.MeetingStartTime >= this.data.MeetingAgenda[i].EndTime
                        || this.data.MeetingEndTime <= this.data.MeetingAgenda[i].StartTime) 
                    {
                        reservedInfoValid = true;
                    }
                    else 
                    {
                        reservedInfoValid = false;
                        subScreenContent = "会议时间冲突，请重新选择哟！"
                    }
                }
            }
            else
            {
                reservedInfoValid = true;
            }
        }

        if (reservedInfoValid == false)
        {
            title = "预订失败"
        }
        else
        {
            this.InsertOneReserveMeetingRecord();
            this.UpdateReservedMeetingAgenda(this.data.MeetingDate);
            this.UpdateReservedMeetingAgenda(this.data.MeetingDate);
            this.setData({
                MeetingStartTime: "",
                MeetingEndTime: "",
                MeetingContent: "",
                MeetingComment: "",
            })
        }

        wx.showModal({
            title: title,
            content: subScreenContent,
            confirmText: "确定",
            cancelText: "取消",
            success: function (res) {
                console.log(res);
                if (res.confirm) {
                    console.log('用户点击确定')
                } else {
                    console.log('用户点击取消')
                }
            }
        });
    },

    CommentValidCheck: function (MeetingComment)
    {
        var num = /[0-9]/;
        var letter = /[a-z]/i;
        var cnGb = new RegExp("[\\u4E00-\\u9FFF]+", "g");

        if ((MeetingComment.length > 5) && num.test(MeetingComment) 
            && (letter.test(MeetingComment) || cnGb.test(MeetingComment)))
        {
            return 1;
        }

        return 0;
    },

    MeetingContentChange: function(e)
    {
        this.setData({
            MeetingContent: e.detail.value
        })
    },

    BindDateChange: function(e)
    {
        this.setData({
            MeetingDate: e.detail.value,
            bNoMeeting: true
        })

        this.UpdateReservedMeetingAgenda(e.detail.value);
    },

    BindStartTimeChange: function(e)
    {
        this.setData({
            MeetingStartTime: e.detail.value
        })
    },

    BindEndTimeChange: function (e) {
        this.setData({
            MeetingEndTime: e.detail.value
        })
        if (e.detail.value <= this.data.MeetingStartTime)
        {
            //TODO: pop up a sub-screen to inform time not valid
            console.log("Time is in-valid!")
            wx.showModal({
                title: '时段错误',
                content: '结束时间必须比开始时间晚！',
                confirmText: "确定",
                cancelText: "取消",
                success: function (res) {
                    console.log(res);
                    if (res.confirm) {
                        console.log('用户点击确定')
                    } else {
                        console.log('用户点击取消')
                    }
                }
            });
        }
    },

    MeetingCommentChange: function(e)
    {
        this.setData({
            MeetingComment: e.detail.value
        })
    },

    UpdateReservedMeetingAgenda: function(Date)
    {
        // get meeting list of this date from cloud
        db.collection('ReservedRecord').where({
            Date: Date,
            RoomSelectNum: app.globalData.RoomSelectNum
        }).get().then(res => {
            console.log(res.data)
            
            if(res.data.length > 1)
            {
                this.setData({
                    MeetingAgenda: this.SortMeetingList(res.data),
                    bNoMeeting: false
                })
            }
            else if(res.data.length == 1)
            {
                var MeetingAgendaTemp = res.data;

                MeetingAgendaTemp[0].Index = 0;
                if(this.DelectEnable(MeetingAgendaTemp[0]._openid))
                {
                    MeetingAgendaTemp[0].DelectEnable = 1;
                }
                else
                {
                    MeetingAgendaTemp[0].DelectEnable = 0;
                }
                this.setData({
                    MeetingAgenda: MeetingAgendaTemp,
                    bNoMeeting: false
                })
            }
            else
            {
                this.setData({
                    MeetingAgenda: '',
                    bNoMeeting: true
                })
            }
            
        })
    },

    SortMeetingList: function(MeetingListSort)
    {
        var MeetingList = MeetingListSort;

        if(MeetingList.length > 0)
        {
            for(var i = 0; i < MeetingList.length - 1; i++)
            {
                for(var j = 0; j < MeetingList.length - 1 - i; j++)
                {
                    if (MeetingList[j].StartTime > MeetingList[j + 1].StartTime)
                    {
                        var tempList = MeetingList[j];
                        MeetingList[j] = MeetingList[j + 1];
                        MeetingList[j + 1] = tempList;
                    }
                }
            }

            for(i = 0; i < MeetingList.length; i++)
            {
                MeetingList[i].Index = i;
                if (this.DelectEnable(MeetingList[i]._openid))
                {
                    MeetingList[i].DelectEnable = 1;
                }
                else
                {
                    MeetingList[i].DelectEnable = 0;
                }
            }
        }

        return MeetingList;
    },

    DelectEnable: function(RecordOpenId)
    {
        return ((this.data.UserOpenId == RecordOpenId)
            || (this.data.UserOpenId == "o2XNp5CE3xo8m3RwBS60FuRscRTk")
            || (this.data.UserOpenId == "o2XNp5CL4xhw4yD0oyqpu3GRTycw"));
    },

    DelectButtonClick: function(e)
    {
        console.log(e.currentTarget.dataset.value);
        var MeetingDataTemp = this.data.MeetingDate;
        var myThis = this;

        wx.showModal({
            title: "删除会议",
            content: "是否确定删除本条会议预定记录？",
            confirmText: "确定",
            cancelText: "取消",
            success: function (res) {
                console.log(res);
                if (res.confirm) {
                    console.log('用户点击确定')
                    //myThis.DeleteRecordCloud(e.currentTarget.dataset.value)
                    //try
                    //{
                    //    db.collection('ReservedRecord').doc(e.currentTarget.dataset.value).remove()
                    //}catch (e) {
                    //    console.error(e)
                    //}
                    db.collection('ReservedRecord').doc(e.currentTarget.dataset.value).remove({
                        success: function (res) {
                            console.log("Delect record ok");
                        },
                        fail: console.error
                    })
                    myThis.UpdateReservedMeetingAgenda(MeetingDataTemp);
                } else {
                    console.log('用户点击取消')
                }
            }
        });
    },

    DeleteRecordCloud: function(id)
    {
        var myThis = this;
        var MeetingDataTemp = this.data.MeetingDate;

        wx.cloud.callFunction({
            name: "deleteRecord",
            data: {
                _id: id,
            },
            success: res => {
                console.log(id)
                console.log('[云函数] 删除成功！！ ', res)
                myThis.UpdateReservedMeetingAgenda(MeetingDataTemp);
            },
            fail: err => {
                console.error('[云函数] 调用失败', err)
            }
        })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function () {
        wx.cloud.callFunction({
            name: 'login',
            complete: res => {
                console.log('callFunction test result: ', res.result.openid);
                this.setData({
                    UserOpenId: res.result.openid
                })
            }
        })
        this.RefreshReservedMeetingScreen();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.RefreshReservedMeetingScreen();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})