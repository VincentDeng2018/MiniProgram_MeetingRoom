//app.js
wx.cloud.init()
const db = wx.cloud.database()

App({
    globalData: {
        RoomSelectNum: 255,
        MeetingRoomList:
        [
            { Name: '1号会议室', Location: 'N/A', Capacity: '0', Tools: 'N/A'},
            { Name: '2号会议室', Location: 'N/A', Capacity: '0', Tools: 'N/A'},
            { Name: '3号会议室', Location: 'N/A', Capacity: '0', Tools: 'N/A'},
        ],

        RefreshRoomListDone: 0
    },
    onLaunch: function () {
    
        if (!wx.cloud) {
            console.error('请使用 2.2.3 或以上的基础库以使用云能力')
        } else {
            wx.cloud.init({
            // env 参数说明：
            //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
            //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
            //   如不填则使用默认环境（第一个创建的环境）
            // env: 'my-env-id',
            traceUser: true,
        })
        }

        console.log("App launch!");
    },

    getRoomListFromCloud: function(e)
    {
        console.log(e);

        if(this.globalData.RefreshRoomListDone == 1)
        {
            console.log("Already got from cloud");
        }
        else
        {
            db.collection('RoomList').get().then(res => {
                console.log(res.data);

                //start to update global data of room list 
                if (res.data.length > 0) {
                    var i;

                    for (i = 0; i < res.data.length; i++) {
                        this.globalData.MeetingRoomList[i].Name = res.data[i].Name;
                        this.globalData.MeetingRoomList[i].Capacity = res.data[i].Capacity;
                        this.globalData.MeetingRoomList[i].Location = res.data[i].Location;
                        this.globalData.MeetingRoomList[i].Tools = res.data[i].Tools;
                    }
                    this.globalData.RefreshRoomListDone = 1;
                    console.log(this.globalData.MeetingRoomList);
                }
            }).catch(err => {
                console.log(err);
            })
        }
    },
  
    getSelectRoomNumber: function()
    {
        return this.globalData.RoomSelectNum;
    },

    setSelectRoomNumber: function (selectRoomNum) 
    {
        if (selectRoomNum < this.globalData.MeetingRoomList.length)
        {
            this.globalData.RoomSelectNum = selectRoomNum;
            console.log("Select Room:" + selectRoomNum);
        }
        else
        {
            console.log("Room number out of range!");
        }
    },

    getRoomInfo: function(RoomNumber)
    {
        if(this.globalData.RefreshRoomListDone == 0)
        {
            this.getRoomListFromCloud();
        }

        // means get total array
        if (RoomNumber == 255)
        {
            console.log("Get all Rooms");  
            return this.globalData.MeetingRoomList;
        }
        else if (RoomNumber < this.globalData.MeetingRoomList.length)
        {
            console.log("Get Rooms #" + RoomNumber);  
            return this.globalData.MeetingRoomList[RoomNumber];
        }
        else
        {
            console.log("Out of range");
            return null;
        }
    },

    insertOneReserveMeetingRecord: function()
    {
        db.collection('ReservedRecord').add({
            // data 字段表示需新增的 JSON 数据
            data: {
              index: 0,
              date: '20190915',
              startTime: '08:30',
              endTime: '09:30',
              meetingTopic: 'miniprogram test',
              comment: 'VincentDeng - 15914137911'
            }
          })
          .then(res => {
            console.log(res)
          })
          .catch(console.error)
    }
})
